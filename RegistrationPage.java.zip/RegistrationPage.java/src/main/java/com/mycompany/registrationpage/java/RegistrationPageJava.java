import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class RegistrationPage extends JFrame implements ActionListener {

    // UI components
    JLabel labelTitle, labelName, labelSurname, labelEmail, labelPhone, labelUsername, labelPassword;
    JTextField textName, textSurname, textEmail, textPhone, textUsername;
    JPasswordField textPassword;
    JButton togglePasswordBtn; // Button to show/hide password
    JButton buttonRegister;

    // Registered credentials
    String registeredUsername;
    String registeredPassword;

    public RegistrationPage() {
        setTitle("ChatApp Registration Page");

        // Main panel layout setup
        JPanel mainPanel = new JPanel(new GridLayout(8, 2, 10, 10));
        mainPanel.setBackground(new Color(255, 228, 240));
        setContentPane(mainPanel);

        // Title
        labelTitle = new JLabel("User Registration", JLabel.CENTER);
        labelTitle.setFont(new Font("Arial", Font.BOLD, 20));
        labelTitle.setOpaque(true);
        labelTitle.setBackground(new Color(255, 182, 193));
        labelTitle.setForeground(Color.BLACK);

        // Labels
        labelName = new JLabel("First Name:");
        labelSurname = new JLabel("Last Name:");
        labelEmail = new JLabel("Email:");
        labelPhone = new JLabel("Cell Phone (e.g. 0834567891):");
        labelUsername = new JLabel("Username:");
        labelPassword = new JLabel("Password:");

        // Text fields
        textName = new JTextField();
        textSurname = new JTextField();
        textEmail = new JTextField();
        textPhone = new JTextField();
        textUsername = new JTextField();
        textPassword = new JPasswordField();

        // Eye icon button to toggle password visibility
        togglePasswordBtn = new JButton("👁");
        togglePasswordBtn.setPreferredSize(new Dimension(50, 30));
        togglePasswordBtn.setFocusPainted(false);
        togglePasswordBtn.setBackground(Color.WHITE);
        togglePasswordBtn.addActionListener(e -> {
            togglePasswordVisibility(textPassword);
        });

        // Register button
        buttonRegister = new JButton("Register");
        buttonRegister.addActionListener(this);
        buttonRegister.setBackground(new Color(255, 105, 180));
        buttonRegister.setForeground(Color.WHITE);
        buttonRegister.setFocusPainted(false);
        buttonRegister.setFont(new Font("Arial", Font.BOLD, 14));

        // Adding components to the panel
        mainPanel.add(labelTitle); mainPanel.add(new JLabel());
        mainPanel.add(labelName); mainPanel.add(textName);
        mainPanel.add(labelSurname); mainPanel.add(textSurname);
        mainPanel.add(labelEmail); mainPanel.add(textEmail);
        mainPanel.add(labelPhone); mainPanel.add(textPhone);
        mainPanel.add(labelUsername); mainPanel.add(textUsername);

        // Combine password field and eye icon
        JPanel passwordPanel = new JPanel(new BorderLayout());
        passwordPanel.setBackground(new Color(255, 228, 240));
        passwordPanel.add(textPassword, BorderLayout.CENTER);
        passwordPanel.add(togglePasswordBtn, BorderLayout.EAST);
        mainPanel.add(labelPassword);
        mainPanel.add(passwordPanel);

        mainPanel.add(new JLabel()); mainPanel.add(buttonRegister);

        // Frame setup
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    // Toggle password visibility on/off
    private void togglePasswordVisibility(JPasswordField passwordField) {
        if (passwordField.getEchoChar() == '•') {
            passwordField.setEchoChar((char) 0); // Show password
        } else {
            passwordField.setEchoChar('•'); // Hide password
        }
    }

    // Customize dialog box appearance
    private void setDialogPink() {
        UIManager.put("Panel.background", new Color(255, 228, 240));
        UIManager.put("OptionPane.background", new Color(255, 228, 240));
        UIManager.put("OptionPane.messageForeground", Color.BLACK);
        UIManager.put("OptionPane.buttonFont", new Font("Arial", Font.PLAIN, 13));
    }

    // Validate username format
    private boolean isValidUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Validate password format
    private boolean isValidPassword(String password) {
        return password.length() >= 8 &&
                password.matches(".*[A-Z].*") &&
                password.matches(".*\\d.*") &&
                password.matches(".*[!@#$%^&*()_+=<>?/{}~|].*");
    }

    // Validate South African phone number
    private boolean isValidSAphone(String phone) {
        if (phone.matches("0\\d{9}")) {
            String fullNumber = "+27" + phone.substring(1);
            setDialogPink();
            JOptionPane.showMessageDialog(null, "Cell phone number successfully added: " + fullNumber);
            return true;
        } else {
            setDialogPink();
            JOptionPane.showMessageDialog(null, "Cell phone number incorrectly formatted. It must be 10 digits and start with 0.");
            return false;
        }
    }

    // Handle register button click
    @Override
    public void actionPerformed(ActionEvent e) {
        String firstName = textName.getText();
        String lastName = textSurname.getText();
        String email = textEmail.getText();
        String phone = textPhone.getText();
        String username = textUsername.getText();
        String password = new String(textPassword.getPassword());

        // Validate inputs
        if (!isValidUsername(username)) {
            setDialogPink();
            JOptionPane.showMessageDialog(this, "Username is not correctly formatted. It must contain an underscore (_) and be no more than 5 characters long.");
            return;
        }

        if (!isValidPassword(password)) {
            setDialogPink();
            JOptionPane.showMessageDialog(this, "Password must be at least 8 characters long, include an uppercase letter, a number, and a special character.");
            return;
        }

        if (!isValidSAphone(phone)) {
            return;
        }

        // Save credentials
        registeredUsername = username;
        registeredPassword = password;

        setDialogPink();
        JOptionPane.showMessageDialog(this, "Your account has been registered successfully!");

        // Open login dialog
        performLogin(firstName, lastName);
    }

    // Show login form after registration
    private void performLogin(String firstName, String lastName) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(255, 228, 240));

        // Username and password fields
        JPanel fieldsPanel = new JPanel(new GridLayout(2, 2));
        fieldsPanel.setBackground(new Color(255, 228, 240));
        JTextField inputUsername = new JTextField();
        JPasswordField inputPassword = new JPasswordField();

        // Eye icon button for login password field
        JButton toggleLoginPasswordBtn = new JButton("👁");
        toggleLoginPasswordBtn.setFocusPainted(false);
        toggleLoginPasswordBtn.setBackground(Color.WHITE);
        toggleLoginPasswordBtn.setPreferredSize(new Dimension(50, 30));
        toggleLoginPasswordBtn.addActionListener(e -> togglePasswordVisibility(inputPassword));

        // Add fields to login panel
        fieldsPanel.add(new JLabel("Username:"));
        fieldsPanel.add(inputUsername);
        fieldsPanel.add(new JLabel("Password:"));
        JPanel loginPasswordPanel = new JPanel(new BorderLayout());
        loginPasswordPanel.setBackground(new Color(255, 228, 240));
        loginPasswordPanel.add(inputPassword, BorderLayout.CENTER);
        loginPasswordPanel.add(toggleLoginPasswordBtn, BorderLayout.EAST);
        fieldsPanel.add(loginPasswordPanel);
        panel.add(fieldsPanel, BorderLayout.CENTER);

        // Show login dialog
        setDialogPink();
        int result = JOptionPane.showConfirmDialog(this, panel, "Login", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        // Handle login
        if (result == JOptionPane.OK_OPTION) {
            String enteredUsername = inputUsername.getText();
            String enteredPassword = new String(inputPassword.getPassword());

            if (enteredUsername.equals(registeredUsername) && enteredPassword.equals(registeredPassword)) {
                setDialogPink();
                JOptionPane.showMessageDialog(this, "Welcome to ChatApp");
            } else {
                setDialogPink();
                JOptionPane.showMessageDialog(this, "Username or password incorrect, please try again.");
            }
        }
    }

    // Main method
    public static void main(String[] args) {
        new RegistrationPage();
    }
}